package com.mariaidalis.petcare;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Button btnProductos = findViewById(R.id.btnProductosMaria);
        btnProductos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, ProductosActivity.class);
                startActivity(intent);
            }
        });

        Button btnServicios = findViewById(R.id.btnServiciosMaria);
        btnServicios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, ServiciosActivity.class);
                startActivity(intent);
            }
        });

        Button btnPerfil = findViewById(R.id.btnPerfilMaria);
        btnPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, PerfilMascotaActivity.class);
                startActivity(intent);
            }
        });

        Button btnContacto = findViewById(R.id.btnContactoMaria);
        btnContacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, ContactoActivity.class);
                startActivity(intent);
            }
        });
    }
}
